<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $adminuser=$_POST['username'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tbladmin where  UserName='$adminuser' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['bpmsaid']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
    $msg="Invalid Details.";
    }
  }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>SBS | Login Page</title>

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Font CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- Webfonts -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!-- Animate CSS -->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<!-- Custom JavaScript -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">

<style>
    body {
        background: url('admin/images/admin.jpg') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .login-page {
        background: rgba(255, 255, 255, 0.9);
        padding: 50px;
        border-radius: 10px;
        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
    }
    .login-body input[type="text"], .login-body input[type="password"] {
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 15px;
        width: 100%;
        margin-bottom: 20px;
    }
    .login-body input[type="submit"] {
        background-color: #28a745;
        color: #fff;
        border: none;
        padding: 15px;
        width: 100%;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
    }
    .login-body input[type="submit"]:hover {
        background-color: #218838;
    }
    .forgot-grid {
        text-align: center;
        margin-top: 10px;
    }
    .forgot a {
        color: #007bff;
        text-decoration: none;
    }
    .forgot a:hover {
        text-decoration: underline;
    }
    .login-top h4 {
        text-align: center;
        font-size: 24px;
        margin-bottom: 20px;
    }
</style>
</head> 
<body>
    <div class="login-page">
        <div class="login-top">
            <h4>Welcome back to SBS Admin Panel!</h4>
        </div>
        <div class="login-body">
            <form role="form" method="post" action="">
                <p style="font-size:16px; color:red" align="center">
                    <?php if($msg){ echo $msg; } ?>
                </p>
                <input type="text" class="user" name="username" placeholder="Username" required="true">
                <input type="password" name="password" class="lock" placeholder="Password" required="true">
                <input type="submit" name="login" value="Sign In">
                <div class="forgot-grid">
                    <div class="forgot">
                        <a href="../index.php">Back to Home</a>
                    </div>
                    <div class="forgot">
                        <a href="forgot-password.php">Forgot password?</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
