<?php
require '../vendor/autoload.php'; // If stripe_payment.php is in a subdirectory
\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL'); // Replace with your Stripe Secret Key

session_start();
error_reporting(0);
include('includes/dbconnection.php');

$amount = $_POST['amount'] * 100; // Convert amount to cents
$invid = $_SESSION['invoiceid']; // Invoice ID from session

// Create a new Stripe payment session
try {
    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'LKR',
                'product_data' => [
                    'name' => 'Salon Service Payment',
                ],
                'unit_amount' => $amount,
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'http://localhost/Bookme/bpms/view-invoice.php?session_id={CHECKOUT_SESSION_ID}&invoiceid=' . $invid,
        'cancel_url' => 'http://localhost/Bookme/bpms/view-invoice.php',
    ]);
    
    header("Location: " . $session->url);
    exit();
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
