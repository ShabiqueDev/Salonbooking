<?php
session_start();
include('includes/dbconnection.php');
require '../vendor/autoload.php';

\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL'); // Your Stripe Secret Key

// Check if session_id and invoiceid are set in the URL
if (isset($_GET['session_id']) && isset($_GET['invoiceid'])) {
    $session_id = $_GET['session_id'];
    $invoiceid = intval($_GET['invoiceid']);
    
    // Retrieve the checkout session to confirm payment
    try {
        $session = \Stripe\Checkout\Session::retrieve($session_id);
        
        if ($session && $session->payment_status === 'paid') {
            // Extract payment details
            $amount = $session->amount_total / 100;  // Amount in LKR
            $transactionID = $session->payment_intent;  // Unique Transaction ID
            $paymentMethod = 'Stripe';
            
            // Update tblpayments with the payment status
            $updateQuery = "UPDATE tblpayments 
                            SET PaymentStatus = 'Paid', 
                                TransactionID = '$transactionID', 
                                PaymentMethod = '$paymentMethod', 
                                PaymentDate = NOW(), 
                                Amount = '$amount'
                            WHERE AppointmentNumber = '$invoiceid'";
            
            if (mysqli_query($con, $updateQuery)) {
                echo "Payment status updated successfully!";
            } else {
                echo "Error updating payment status: " . mysqli_error($con);
            }
        } else {
            echo "Payment not confirmed.";
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <title>Salon Booking System | Invoice History</title>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
</head>
<body id="home">
<?php include_once('includes/header.php');?> 

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script>
    $(function () {
        $('.navbar-toggler').click(function () {
            $('body').toggleClass('noscroll');
        });
    });
</script>

<!-- Breadcrumbs -->
<section class="w3l-inner-banner-main">
    <div class="about-inner contact">
        <div class="container">
            <div class="main-titles-head text-center">
                <h3 class="header-name">Invoice History</h3>
                <p class="tiltle-para">View your invoice and payment history below.</p>
            </div>
        </div>
    </div>
    <div class="breadcrumbs-sub">
        <div class="container">
            <ul class="breadcrumbs-custom-path">
                <li class="right-side propClone">
                    <a href="index.php">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a>
                </li>
                <li class="active">Invoice History</li>
            </ul>
        </div>
    </div>
</section>

<section class="w3l-contact-info-main" id="contact">
    <div class="contact-sec">
        <div class="container">
            <div>
                <div class="cont-details">
                    <div class="table-content table-responsive cart-table-content m-t-30">
                        <h3 class="title1">Invoice Details</h3>

                        <?php
                        $invid = intval($_GET['invoiceid']);
                        $ret = mysqli_query($con, "SELECT DISTINCT date(tblinvoice.PostingDate) as invoicedate, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber, tbluser.RegDate 
                        FROM tblinvoice 
                        JOIN tbluser ON tbluser.ID = tblinvoice.Userid 
                        WHERE tblinvoice.BillingId = '$invid'");

                        while ($row = mysqli_fetch_array($ret)) {
                        ?>
                        <div class="table-responsive bs-example widget-shadow">
                            <h4>Invoice #<?php echo $invid; ?></h4>
                            <table class="table table-bordered" width="100%" border="1">
                                <tr>
                                    <th colspan="6">Customer Details</th>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php echo $row['FirstName'] . ' ' . $row['LastName']; ?></td>
                                    <th>Contact no.</th>
                                    <td><?php echo $row['MobileNumber']; ?></td>
                                    <th>Email</th>
                                    <td><?php echo $row['Email']; ?></td>
                                </tr>
                                <tr>
                                    <th>Registration Date</th>
                                    <td><?php echo $row['RegDate']; ?></td>
                                    <th>Invoice Date</th>
                                    <td colspan="3"><?php echo $row['invoicedate']; ?></td>
                                </tr>
                            </table>

                            <table class="table table-bordered" width="100%" border="1">
                                <tr>
                                    <th colspan="3">Services Details</th>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <th>Service</th>
                                    <th>Cost</th>
                                </tr>

                                <?php
                                $ret = mysqli_query($con, "SELECT tblservices.ServiceName, tblservices.Cost, tblinvoice.PaymentStatus  
                                    FROM tblinvoice 
                                    JOIN tblservices ON tblservices.ID = tblinvoice.ServiceId 
                                    WHERE tblinvoice.BillingId = '$invid'");
                                $cnt = 1;
                                $gtotal = 0;
                                $paymentStatus = '';

                                while ($row = mysqli_fetch_array($ret)) {
                                    $paymentStatus = $row['PaymentStatus'];
                                ?>
                                <tr>
                                    <th><?php echo $cnt; ?></th>
                                    <td><?php echo $row['ServiceName']; ?></td>
                                    <td><?php echo $subtotal = $row['Cost']; ?></td>
                                </tr>
                                <?php 
                                    $cnt++;
                                    $gtotal += $subtotal;
                                } ?>

                                <tr>
                                    <th colspan="2" style="text-align:center">Grand Total</th>
                                    <th><?php echo $gtotal; ?></th>
                                </tr>

                                <tr>
                                    <td colspan="3" style="text-align:center;">
                                        <?php if ($paymentStatus === 'Paid') { ?>
                                            <button class="btn btn-danger" disabled>Paid</button>
                                        <?php } else { ?>
                                            <form action="stripe_payment.php" method="POST">
                                                <input type="hidden" name="amount" value="<?php echo $gtotal; ?>">
                                                <input type="hidden" name="invoiceid" value="<?php echo $invid; ?>">
                                                <button type="submit" class="btn btn-success">Pay Now</button>
                                            </form>
                                        <?php } ?>
                                    </td>
                                </tr>
                            </table>
                            <p style="margin-top:1%" align="center">
                                <i class="fa fa-print fa-2x" style="cursor: pointer;" onclick="CallPrint(this.value)"></i>
                            </p>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include_once('includes/footer.php'); ?>

<!-- Move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-long-arrow-up"></span>
</button>
<script>
    window.onscroll = function () {
        scrollFunction();
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("movetop").style.display = "block";
        } else {
            document.getElementById("movetop").style.display = "none";
        }
    }

    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>

</body>
</html>
